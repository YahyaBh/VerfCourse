<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\CertificateController;
use App\Http\Controllers\PageController;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

/*
|--------------------------------------------------------------------------
| Public Routes
|--------------------------------------------------------------------------
*/

Route::get('/', function () {
    return Inertia::render('Welcome', [
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'laravelVersion' => Application::VERSION,
        'phpVersion' => PHP_VERSION,
    ]);
});

// Certificate verification (external + internal)
Route::get('/{certificate_number}', [CertificateController::class, 'verifyExt'])
    ->where('certificate_number', 'WEBC-[A-Z0-9-]+');

Route::get('/verify-certificate', [CertificateController::class, 'index'])->name('certificates.index');
Route::post('/certificates/verify', [CertificateController::class, 'verify'])->name('certificates.verify');
Route::get('/certificates/verify', function () {
    return redirect('/');
});

Route::get('/certificate/{id}', [CertificateController::class, 'show'])->name('certificates.show');
Route::get('/certificates/{id}/download', [CertificateController::class, 'downloadPDF'])
    ->name('certificates.download');

/*
|--------------------------------------------------------------------------
| Dashboard + Authenticated Routes
|--------------------------------------------------------------------------
*/
Route::get('/dashboard', function () {
    return Inertia::render('Admin/AdminDashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::post('/admin/certificate', [CertificateController::class, 'store'])->name('certificates.store');
    Route::get('/admin/certificate', function () {
        return redirect('/login');
    });

    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

/*
|--------------------------------------------------------------------------
| Catch-All 404 Route (must always be last)
|--------------------------------------------------------------------------
*/
Route::get('/{any}', [PageController::class, 'notFound'])->where('any', '.*');

require __DIR__ . '/auth.php';
