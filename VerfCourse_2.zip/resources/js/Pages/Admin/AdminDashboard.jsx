import React, { useState } from "react";
import { router, Head, Link } from "@inertiajs/react";

const AdminDashboard = () => {
    const [name, setName] = useState("");
    const [courseName] = useState("Full Stack Web Development Course");
    const [issuedAt, setIssuedAt] = useState("");
    const [courseLink, setCourseLink] = useState("");
    const [loading, setLoading] = useState(false);
    const [message, setMessage] = useState(null);

    const handleCreate = async (e) => {
        e.preventDefault();
        setLoading(true);
        setMessage(null);

        const formData = new FormData();
        formData.append("name", name);
        formData.append("course", courseName);
        formData.append("issued_date", issuedAt);
        formData.append("course_link", courseLink);

        try {
            await router.post("/admin/certificate", formData, {
                onSuccess: () => {
                    setMessage({ type: "success", text: "✅ Certificate created successfully!" });
                    setName("");
                    setIssuedAt("");
                    setCourseLink("");
                },
                onError: () => {
                    setMessage({ type: "error", text: "⚠️ Please check your inputs." });
                },
            });
        } catch (error) {
            setMessage({ type: "error", text: "❌ Something went wrong." });
            console.log(error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <>
            <Head title="Admin Dashboard" />

            <div className="relative min-h-screen bg-[#1e1e1e] text-white flex flex-col items-center py-16 px-4 overflow-hidden">
                {/* Blurred glowing background */}
                <div className="absolute top-[-80px] left-[-80px] w-96 h-96 bg-[#FFE662]/20 rounded-full filter blur-3xl animate-blob"></div>
                <div className="absolute bottom-[-100px] right-[-80px] w-96 h-96 bg-[#FFD633]/20 rounded-full filter blur-3xl animate-blob animation-delay-3000"></div>

                <h1 className="text-5xl font-extrabold text-[#FFE662] mb-12 text-center relative z-10 animate-fadeIn">
                    Admin Dashboard
                </h1>

                {message && (
                    <div
                        className={`mb-8 px-6 py-4 rounded-xl text-center w-full max-w-2xl mx-auto relative z-10 ${
                            message.type === "success"
                                ? "bg-green-600/80"
                                : "bg-red-600/80"
                        } text-white backdrop-blur-md animate-fadeIn`}
                    >
                        {message.text}
                    </div>
                )}

                <form
                    onSubmit={handleCreate}
                    className="relative z-10 bg-[#2b2b2b]/70 backdrop-blur-xl p-12 rounded-3xl shadow-2xl max-w-2xl w-full space-y-6 animate-fadeInUp"
                >
                    <div>
                        <label className="block mb-2 font-semibold text-[#FFE662]">Student Name</label>
                        <input
                            type="text"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            className="w-full px-5 py-3 rounded-2xl bg-[#1e1e1e]/70 border border-[#444] focus:border-[#FFE662] outline-none transition"
                            required
                        />
                    </div>

                    <div>
                        <label className="block mb-2 font-semibold text-[#FFE662]">Course Name</label>
                        <input
                            type="text"
                            value={courseName}
                            disabled={true}
                            className="w-full px-5 py-3 rounded-2xl bg-[#1e1e1e]/50 border border-[#444] focus:border-[#FFE662] outline-none transition disabled:opacity-60"
                        />
                    </div>

                    <div>
                        <label className="block mb-2 font-semibold text-[#FFE662]">Certificate Number</label>
                        <p className="text-gray-300 italic">
                            Will be generated automatically as{" "}
                            <span className="text-[#FFE662]">WEBC-[year]-XXXXX</span>.
                        </p>
                    </div>

                    <div>
                        <label className="block mb-2 font-semibold text-[#FFE662]">Issued At</label>
                        <input
                            type="date"
                            value={issuedAt}
                            onChange={(e) => setIssuedAt(e.target.value)}
                            className="w-full px-5 py-3 rounded-2xl bg-[#1e1e1e]/70 border border-[#444] focus:border-[#FFE662] outline-none transition"
                            required
                        />
                    </div>

                    <div>
                        <label className="block mb-2 font-semibold text-[#FFE662]">Course Link (optional)</label>
                        <input
                            type="url"
                            value={courseLink}
                            onChange={(e) => setCourseLink(e.target.value)}
                            placeholder="https://webinadigital.com/course"
                            className="w-full px-5 py-3 rounded-2xl bg-[#1e1e1e]/70 border border-[#444] focus:border-[#FFE662] outline-none transition"
                        />
                    </div>

                    <button
                        type="submit"
                        className="w-full bg-gradient-to-r from-[#FFE662] to-[#FFD633] text-[#1e1e1e] font-bold py-4 rounded-2xl hover:opacity-90 transform transition duration-300 shadow-lg"
                        disabled={loading}
                    >
                        {loading ? "Creating..." : "Create Certificate"}
                    </button>
                </form>

                <Link
                    href="/"
                    className="mt-12 text-[#FFE662] hover:underline font-semibold transition relative z-10"
                >
                    Back to Home
                </Link>

                <footer className="relative z-10 mt-16 text-gray-400 text-sm">
                    © {new Date().getFullYear()} WEBINA Digital. All rights reserved.
                </footer>
            </div>

            {/* Animations */}
            <style>{`
                @keyframes blob {
                    0%,100% { transform: translate(0,0) scale(1); }
                    33% { transform: translate(30px,-50px) scale(1.1); }
                    66% { transform: translate(-20px,20px) scale(0.9); }
                }
                .animate-blob { animation: blob 8s infinite; }
                .animation-delay-3000 { animation-delay: 3s; }
                .animate-fadeIn { animation: fadeIn 1s ease forwards; }
                .animate-fadeInUp { animation: fadeInUp 1s ease forwards; }
                @keyframes fadeIn { from {opacity:0;} to{opacity:1;} }
                @keyframes fadeInUp { from {opacity:0; transform:translateY(20px);} to{opacity:1; transform:translateY(0);} }
            `}</style>
        </>
    );
};

export default AdminDashboard;
