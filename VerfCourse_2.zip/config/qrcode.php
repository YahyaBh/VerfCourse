<?php


return [
    'format' => 'png',

    'default' => [
        'renderer' => 'gd',
        'size' => 200,
        'margin' => 10,
        'color' => [
            'r' => 0,
            'g' => 0,
            'b' => 0,
            'a' => 0,
        ],
    ],
];
